# -*- coding: utf-8 -*-
"""
router_productos.py -- Los endpoints del recurso /productos.

Listado paginado con búsqueda y filtros combinables, alta, PATCH parcial,
baja lógica, y asociar/quitar etiquetas (relación N a N).
"""

from typing import Annotated

from fastapi import APIRouter, HTTPException, Path, Query, status

import service
from database import SessionDep
from schemas import (
    ProductoCreate,
    ProductoPatch,
    ProductoPublic,
    ProductosPaginados,
)
from service import ConflictoError, NoEncontradoError

router = APIRouter(prefix="/productos", tags=["Productos"])

ProductoId = Annotated[int, Path(gt=0, description="ID del producto")]
EtiquetaId = Annotated[int, Path(gt=0, description="ID de la etiqueta")]


@router.get("/", response_model=ProductosPaginados)
def listar_productos(
    session: SessionDep,
    q: Annotated[str | None, Query(min_length=1, max_length=50)] = None,
    categoria_id: Annotated[int | None, Query(gt=0)] = None,
    etiqueta_id: Annotated[int | None, Query(gt=0)] = None,
    solo_con_stock: bool = False,
    skip: Annotated[int, Query(ge=0)] = 0,
    limit: Annotated[int, Query(ge=1, le=50)] = 10,
):
    """Listado paginado de activos, ordenado por id.

    Parámetros: q, categoria_id, etiqueta_id, solo_con_stock, skip y limit.
    """
    total, items = service.listar_productos(
        session,
        q=q,
        categoria_id=categoria_id,
        etiqueta_id=etiqueta_id,
        solo_con_stock=solo_con_stock,
        skip=skip,
        limit=limit,
    )
    return {"total": total, "items": items}


@router.get("/{producto_id}", response_model=ProductoPublic)
def obtener_producto(producto_id: ProductoId, session: SessionDep):
    """Devuelve un producto, aunque esté dado de baja."""
    try:
        return service.obtener_producto(session, producto_id)
    except NoEncontradoError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(error))


@router.post("/", response_model=ProductoPublic, status_code=status.HTTP_201_CREATED)
def crear_producto(datos: ProductoCreate, session: SessionDep):
    try:
        return service.crear_producto(session, datos)
    except NoEncontradoError as error:  # categoría inexistente o inactiva
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(error))
    except ConflictoError as error:  # nombre repetido
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(error))


@router.patch("/{producto_id}", response_model=ProductoPublic)
def patch_producto(producto_id: ProductoId, datos: ProductoPatch, session: SessionDep):
    """Cambia solo los campos enviados."""
    try:
        return service.patch_producto(session, producto_id, datos)
    except NoEncontradoError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(error))
    except ConflictoError as error:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(error))


@router.delete("/{producto_id}", response_model=ProductoPublic)
def desactivar_producto(producto_id: ProductoId, session: SessionDep):
    """Baja lógica: devuelve el producto con activo en false."""
    try:
        return service.desactivar_producto(session, producto_id)
    except NoEncontradoError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(error))
    except ConflictoError as error:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(error))


@router.post("/{producto_id}/etiquetas/{etiqueta_id}", response_model=ProductoPublic,
             status_code=status.HTTP_201_CREATED)
def asociar_etiqueta(
    producto_id: ProductoId, etiqueta_id: EtiquetaId, session: SessionDep
):
    """Asocia una etiqueta y devuelve el producto."""
    try:
        return service.asociar_etiqueta(session, producto_id, etiqueta_id)
    except NoEncontradoError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(error))
    except ConflictoError as error:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(error))


@router.delete("/{producto_id}/etiquetas/{etiqueta_id}",
               status_code=status.HTTP_204_NO_CONTENT)
def desasociar_etiqueta(producto_id: ProductoId, etiqueta_id: EtiquetaId,
                        session: SessionDep):
    """Quita la asociación, sin cuerpo en la respuesta."""
    try:
        service.desasociar_etiqueta(session, producto_id, etiqueta_id)
    except NoEncontradoError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(error))
