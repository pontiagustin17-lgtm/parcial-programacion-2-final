# -*- coding: utf-8 -*-
"""
router_pedidos.py -- Los endpoints del recurso /pedidos.

Creación completa o nula (un solo commit), listado paginado con filtro por
estado, resumen del negocio, detalle con líneas y transiciones de estado.
"""

from typing import Annotated

from fastapi import APIRouter, HTTPException, Path, Query, status

import service
from database import SessionDep
from schemas import (
    EstadoUpdate,
    PedidoCreate,
    PedidoPublic,
    PedidosPaginados,
    ResumenPublic,
)
from service import ConflictoError, NoEncontradoError

router = APIRouter(prefix="/pedidos", tags=["Pedidos"])

PedidoId = Annotated[int, Path(gt=0, description="ID del pedido")]


@router.post("/", response_model=PedidoPublic, status_code=status.HTTP_201_CREATED)
def crear_pedido(datos: PedidoCreate, session: SessionDep):
    """Crea un pedido con sus líneas. Todo o nada: un solo commit."""
    try:
        return service.crear_pedido(session, datos)
    except NoEncontradoError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(error))
    except ConflictoError as error:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(error))


@router.get("/", response_model=PedidosPaginados)
def listar_pedidos(
    session: SessionDep,
    estado: Annotated[service.EstadoPedido | None, Query()] = None,
    skip: Annotated[int, Query(ge=0)] = 0,
    limit: Annotated[int, Query(ge=1, le=50)] = 10,
):
    """Listado paginado, del más nuevo al más viejo. Parámetros: estado, skip y limit."""
    total, items = service.listar_pedidos(session, estado=estado, skip=skip, limit=limit)
    return {"total": total, "items": items}


@router.get("/resumen", response_model=ResumenPublic)
def resumen_pedidos(session: SessionDep):
    """Cantidad de pedidos por estado e ingresos de los entregados."""
    return service.resumen_pedidos(session)


@router.get("/{pedido_id}", response_model=PedidoPublic)
def obtener_pedido(pedido_id: PedidoId, session: SessionDep):
    """Devuelve un pedido con sus líneas."""
    try:
        return service.obtener_pedido(session, pedido_id)
    except NoEncontradoError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(error))


@router.patch("/{pedido_id}/estado", response_model=PedidoPublic)
def cambiar_estado_pedido(pedido_id: PedidoId, datos: EstadoUpdate,
                          session: SessionDep):
    """Cambia el estado según las transiciones válidas."""
    try:
        return service.cambiar_estado_pedido(session, pedido_id, datos.estado)
    except NoEncontradoError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(error))
    except ConflictoError as error:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(error))
