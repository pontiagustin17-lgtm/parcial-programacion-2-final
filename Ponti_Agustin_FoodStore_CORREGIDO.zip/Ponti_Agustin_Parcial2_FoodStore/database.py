# -*- coding: utf-8 -*-
"""
database.py -- El ENGINE (uno solo, global) y la SESIÓN por request.

Esta capa es la única que sabe DÓNDE está la base de datos. La URL sale de la
variable de entorno DATABASE_URL:

  - sin configurar  -> SQLite en un archivo local (foodstore.db): no requiere instalar nada
  - PostgreSQL real -> postgresql+psycopg://usuario:clave@localhost:5432/foodstore

Cambiar la URL es lo ÚNICO que hace falta para pasar de SQLite a PostgreSQL:
el resto del proyecto no se entera (para eso existe el ORM).

Las pruebas (probar_api.py) arman su propio engine de SQLite
en memoria y reemplazan get_session con app.dependency_overrides.
"""

import os
from typing import Annotated

from fastapi import Depends
from sqlmodel import Session, SQLModel, create_engine

import models  # noqa: F401  -- importarlo registra las tablas en SQLModel.metadata

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///foodstore.db")

# check_same_thread=False es solo para SQLite: FastAPI atiende cada request
# en un hilo distinto y SQLite, por defecto, no lo permite.
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}

# UN solo engine para toda la aplicación (es costoso de crear: tiene el pool de conexiones).
engine = create_engine(DATABASE_URL, connect_args=connect_args)


def crear_tablas() -> None:
    """Crea las tablas que todavía no existen (no modifica las que ya están)."""
    SQLModel.metadata.create_all(engine)


def get_session():
    """Una sesión POR REQUEST: se abre al entrar y se cierra sola al terminar."""
    with Session(engine) as session:
        yield session


# Alias reutilizable: se declara UNA vez y se usa en todos los endpoints.
SessionDep = Annotated[Session, Depends(get_session)]
