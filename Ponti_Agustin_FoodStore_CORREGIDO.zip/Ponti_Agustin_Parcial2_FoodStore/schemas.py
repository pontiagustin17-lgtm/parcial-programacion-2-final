# -*- coding: utf-8 -*-
"""
schemas.py -- Los CONTRATOS de la API: qué datos entran y qué datos salen.

Todo lo que viaja por HTTP se declara aquí. Ninguna otra capa valida tipos
"a mano": si un dato llegó hasta el service, ya es válido (si no, FastAPI
respondió 422 antes de entrar).

Modelos segregados (ninguno es una tabla, por eso NO llevan table=True):
  - ...Create:  ENTRADA del alta
  - ...Public:  SALIDA (sin datos internos)
  - ...Con...:  SALIDA anidada (un solo nivel, SIN ciclos)
  - ...Patch:   ENTRADA de actualización parcial (campos opcionales)

Nunca se devuelve una clase de models.py (una tabla): se filtra con response_model.
"""

from datetime import datetime
from typing import Optional

from pydantic import ConfigDict, field_validator
from sqlmodel import Field, SQLModel

from models import FormaPago, EstadoPedido


# ======================================================================
# Detalle de pedido (salida de una línea)
# ======================================================================
class DetallePublic(SQLModel):
    id: int
    producto_id: int
    nombre_producto: str
    precio_unitario: float
    cantidad: int
    subtotal: float


# ======================================================================
# Etiquetas
# ======================================================================
class EtiquetaCreate(SQLModel):
    """ENTRADA del alta de una etiqueta."""
    nombre: str = Field(min_length=2, max_length=30)


class EtiquetaPublic(SQLModel):
    """SALIDA de una etiqueta."""
    id: int
    nombre: str


# ======================================================================
# Categorías
# ======================================================================
class CategoriaCreate(SQLModel):
    """ENTRADA del alta y del reemplazo (PUT) de una categoría."""
    nombre: str = Field(min_length=2, max_length=50)
    descripcion: Optional[str] = Field(default="", max_length=200)


class CategoriaPublic(SQLModel):
    """SALIDA de una categoría."""
    id: int
    nombre: str
    descripcion: str
    activo: bool


class CategoriaConProductos(CategoriaPublic):
    """Detalle de una categoría: sus productos vienen anidados."""
    productos: list["ProductoPublic"] = []


# ======================================================================
# Productos
# ======================================================================
class ProductoCreate(SQLModel):
    """ENTRADA del alta de un producto."""
    nombre: str = Field(min_length=3, max_length=60)
    descripcion: Optional[str] = Field(default="", max_length=200)
    precio: float = Field(gt=0)
    stock: int = Field(default=0, ge=0)
    imagen_url: Optional[str] = Field(default=None, max_length=255)
    categoria_id: int = Field(gt=0)


class ProductoPatch(SQLModel):
    # Rechaza campos no contemplados (por ejemplo, `activo`).
    model_config = ConfigDict(extra="forbid")

    """ENTRADA del PATCH parcial: solo los campos que llegan se actualizan.

    No acepta `activo`: el alta/baja lógica de un producto solo se hace por
    los endpoints dedicados, nunca por un PATCH parcial.
    `nombre` es opcional (se omite si no se cambia), pero si se envía no puede
    ser nulo: ``{"nombre": null}`` se rechaza con 422.
    """
    nombre: Optional[str] = Field(default=None, min_length=3, max_length=60)
    descripcion: Optional[str] = Field(default=None, max_length=200)
    precio: Optional[float] = Field(default=None, gt=0)
    stock: Optional[int] = Field(default=None, ge=0)
    imagen_url: Optional[str] = Field(default=None, max_length=255)
    categoria_id: Optional[int] = Field(default=None, gt=0)

    @field_validator("nombre", "descripcion", "precio", "stock", "categoria_id", mode="before")
    @classmethod
    def _campos_no_nullable_no_pueden_ser_nulos(cls, v):
        # En un PATCH, None significa explícitamente null, no "no modificar".
        # imagen_url sí admite null porque la columna es nullable.
        if v is None:
            raise ValueError("el campo no puede ser nulo; omitilo si no lo vas a cambiar")
        return v


class ProductoPublic(SQLModel):
    """SALIDA de un producto: incluye su categoría y sus etiquetas."""
    id: int
    nombre: str
    descripcion: str
    precio: float
    stock: int
    imagen_url: Optional[str]
    categoria_id: int
    activo: bool
    categoria: Optional[CategoriaPublic] = None
    etiquetas: list[EtiquetaPublic] = []


class ProductoItem(SQLModel):
    """Un ítem del listado paginado de productos (mismos campos que ProductoPublic)."""
    id: int
    nombre: str
    descripcion: str
    precio: float
    stock: int
    imagen_url: Optional[str]
    categoria_id: int
    activo: bool
    categoria: Optional[CategoriaPublic] = None
    etiquetas: list[EtiquetaPublic] = []


class ProductosPaginados(SQLModel):
    """Forma de los listados paginados: total de filtrados + items de la página."""
    total: int
    items: list[ProductoItem]


# ======================================================================
# Pedidos
# ======================================================================
class DetalleCreate(SQLModel):
    """ENTRADA de una línea de pedido: qué producto y cuántas unidades."""
    producto_id: int = Field(gt=0)
    cantidad: int = Field(ge=1)


class PedidoBase(SQLModel):
    cliente_nombre: str = Field(min_length=3, max_length=80)
    direccion_entrega: str = Field(min_length=5, max_length=200)
    forma_pago: FormaPago
    notas: Optional[str] = Field(default=None, max_length=200)


class PedidoCreate(PedidoBase):
    """ENTRADA de un pedido: datos del cliente y lista de líneas (al menos una)."""
    detalles: list[DetalleCreate] = Field(min_length=1)


class PedidoPublic(SQLModel):
    """SALIDA de un pedido: incluye id, estado, total, fecha y sus líneas."""
    id: int
    cliente_nombre: str
    direccion_entrega: str
    forma_pago: FormaPago
    notas: Optional[str]
    estado: EstadoPedido
    total: float
    fecha: datetime
    detalles: list[DetallePublic] = []


class PedidoItem(SQLModel):
    """Un ítem del listado paginado de pedidos."""
    id: int
    cliente_nombre: str
    direccion_entrega: str
    forma_pago: FormaPago
    notas: Optional[str]
    estado: EstadoPedido
    total: float
    fecha: datetime
    detalles: list[DetallePublic] = []


class PedidosPaginados(SQLModel):
    """Forma de los listados paginados de pedidos."""
    total: int
    items: list[PedidoItem]


class EstadoUpdate(SQLModel):
    """ENTRADA de PATCH /pedidos/{id}/estado: solo el nuevo estado."""
    estado: EstadoPedido


# ======================================================================
# Resumen del negocio
# ======================================================================
class ResumenPublic(SQLModel):
    """SALIDA de GET /pedidos/resumen."""
    pendientes: int
    en_preparacion: int
    entregados: int
    cancelados: int
    ingresos_entregados: float


# Cierre de referencias forward para modelos con relaciones anidadas.
CategoriaConProductos.model_rebuild()
ProductoPublic.model_rebuild()
ProductoItem.model_rebuild()
