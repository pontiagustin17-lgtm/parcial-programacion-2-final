# -*- coding: utf-8 -*-
"""
service.py -- La LÓGICA DE NEGOCIO y el CONTROL DE LA TRANSACCIÓN.

Esta capa NO conoce HTTP: no importa nada de FastAPI y no sabe qué es un 404.
Cuando una regla de negocio se rompe, lanza una excepción DE DOMINIO
(NoEncontradoError, ConflictoError) y es el router quien decide qué código
HTTP le corresponde.

Lo que cambia respecto de la Unidad 6 / GameStore: el dict en memoria desapareció.
Ahora cada función recibe la Session y trabaja contra la base de datos.

    Regla de oro: el service es el ÚNICO que hace add / commit / rollback.
    El router nunca llama a commit.

Los mensajes de las excepciones empiezan con el código de la regla (RN-01 a RN-07):
la API los devuelve en `detail`.

Este archivo implementa las reglas de negocio y el control de transacción.
"""

from datetime import datetime, timezone
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import selectinload
from sqlmodel import Session, func, select

from models import (
    Categoria,
    DetallePedido,
    Etiqueta,
    EstadoPedido,
    Pedido,
    Producto,
    ProductoEtiqueta,
)
from schemas import (
    CategoriaCreate,
    EtiquetaCreate,
    PedidoCreate,
    ProductoCreate,
    ProductoPatch,
)


# ----------------------------------------------------------------------
# Excepciones de dominio
# ----------------------------------------------------------------------
class NoEncontradoError(Exception):
    """El recurso pedido no existe. El router lo traduce a 404."""


class ConflictoError(Exception):
    """La operación choca con el estado actual. El router lo traduce a 409."""


# ----------------------------------------------------------------------
# Helper compartido: el patrón de ESCRITURA de todo el archivo
# ----------------------------------------------------------------------
def _confirmar(session: Session, mensaje_conflicto: str) -> None:
    """Confirma una transacción; ante una restricción incumplida, revierte."""
    try:
        session.commit()
    except IntegrityError as exc:
        session.rollback()
        raise ConflictoError(mensaje_conflicto) from exc


def _guardar(session: Session, entidad, mensaje_conflicto: str):
    """add -> commit -> refresh. Si la base rechaza el dato, rollback y 409."""
    session.add(entidad)
    _confirmar(session, mensaje_conflicto)
    session.refresh(entidad)
    return entidad


# ----------------------------------------------------------------------
# Reglas de negocio: helpers de validación
# ----------------------------------------------------------------------
def _nombre_ya_existe(session, modelo, nombre: str, excluir_id: int | None = None) -> bool:
    """RN-01: el nombre no se repite (sin distinguir mayúsculas), ni siquiera
    en registros dados de baja."""
    consulta = select(modelo.id).where(func.lower(modelo.nombre) == nombre.lower())
    if excluir_id is not None:
        consulta = consulta.where(modelo.id != excluir_id)
    return session.exec(consulta).first() is not None


TRANSICIONES_VALIDAS = {
    EstadoPedido.PENDIENTE: {EstadoPedido.EN_PREPARACION, EstadoPedido.CANCELADO},
    EstadoPedido.EN_PREPARACION: {EstadoPedido.ENTREGADO, EstadoPedido.CANCELADO},
    EstadoPedido.ENTREGADO: set(),
    EstadoPedido.CANCELADO: set(),
}


# ======================================================================
# FASE: CATEGORÍAS
# ======================================================================
def listar_categorias(session: Session) -> list[Categoria]:
    """Categorías ACTIVAS, ordenadas por id."""
    consulta = select(Categoria).where(Categoria.activo == True).order_by(Categoria.id)  # noqa: E712
    return list(session.exec(consulta).all())


def obtener_categoria(session: Session, categoria_id: int) -> Categoria:
    """La categoría con sus productos ya cargados (selectinload). 404 si no existe."""
    consulta = (
        select(Categoria)
        .where(Categoria.id == categoria_id)
        .options(selectinload(Categoria.productos))
    )
    categoria = session.exec(consulta).first()
    if categoria is None:
        raise NoEncontradoError(f"RN-03: no existe una categoría con id {categoria_id}")
    return categoria


def crear_categoria(session: Session, datos: CategoriaCreate) -> Categoria:
    if _nombre_ya_existe(session, Categoria, datos.nombre):
        raise ConflictoError(f"RN-01: ya existe la categoría '{datos.nombre}'")
    categoria = Categoria.model_validate(datos)
    return _guardar(session, categoria, f"RN-01: ya existe la categoría '{datos.nombre}'")


def reemplazar_categoria(session: Session, categoria_id: int, datos: CategoriaCreate) -> Categoria:
    """PUT: reemplaza nombre y descripción."""
    categoria = obtener_categoria(session, categoria_id)  # 404 si no existe
    if _nombre_ya_existe(session, Categoria, datos.nombre, excluir_id=categoria_id):
        raise ConflictoError(f"RN-01: ya existe la categoría '{datos.nombre}'")
    categoria.sqlmodel_update(datos.model_dump())
    return _guardar(session, categoria, f"RN-01: ya existe la categoría '{datos.nombre}'")


def desactivar_categoria(session: Session, categoria_id: int) -> Categoria:
    """Baja LÓGICA: solo si no tiene productos activos (RN-02)."""
    categoria = obtener_categoria(session, categoria_id)  # 404 si no existe
    if not categoria.activo:
        raise ConflictoError(f"RN-02: la categoría {categoria_id} ya está dada de baja")
    # RN-02: una categoría con productos activos no se da de baja.
    productos_activos = [p for p in categoria.productos if p.activo]
    if productos_activos:
        raise ConflictoError(
            f"RN-02: la categoría '{categoria.nombre}' tiene {len(productos_activos)} "
            f"producto(s) activo(s): no se puede dar de baja")
    categoria.activo = False
    return _guardar(session, categoria, f"No se pudo dar de baja la categoría {categoria_id}")


# ======================================================================
# FASE: ETIQUETAS
# ======================================================================
def listar_etiquetas(session: Session) -> list[Etiqueta]:
    """Etiquetas, ordenadas por id."""
    consulta = select(Etiqueta).order_by(Etiqueta.id)
    return list(session.exec(consulta).all())


def crear_etiqueta(session: Session, datos: EtiquetaCreate) -> Etiqueta:
    if _nombre_ya_existe(session, Etiqueta, datos.nombre):
        raise ConflictoError(f"RN-01: ya existe la etiqueta '{datos.nombre}'")
    etiqueta = Etiqueta.model_validate(datos)
    return _guardar(session, etiqueta, f"RN-01: ya existe la etiqueta '{datos.nombre}'")


def eliminar_etiqueta(session: Session, etiqueta_id: int) -> None:
    """Borrado FÍSICO, solo si la etiqueta no está en uso (RN-02)."""
    etiqueta = session.get(Etiqueta, etiqueta_id)
    if etiqueta is None:
        raise NoEncontradoError(f"RN-03: no existe una etiqueta con id {etiqueta_id}")
    # RN-02: una etiqueta en uso no se elimina.
    if etiqueta.productos:
        raise ConflictoError(
            f"RN-02: la etiqueta '{etiqueta.nombre}' tiene {len(etiqueta.productos)} "
            f"producto(s) asociado(s): no se puede eliminar")
    session.delete(etiqueta)
    _confirmar(session, f"No se pudo eliminar la etiqueta {etiqueta_id}")


# ======================================================================
# FASE: PRODUCTOS
# ======================================================================
def listar_productos(
    session: Session,
    q: str | None = None,
    categoria_id: int | None = None,
    etiqueta_id: int | None = None,
    solo_con_stock: bool = False,
    skip: int = 0,
    limit: int = 10,
) -> tuple[int, list[Producto]]:
    """Productos ACTIVOS, ordenados por id, con filtros opcionales y paginación.

    Devuelve (total_coincidencias, items_de_la_pagina).
    """
    consulta = select(Producto).where(Producto.activo == True)  # noqa: E712

    if q is not None:
        q_like = f"%{q.lower()}%"
        consulta = consulta.where(
            func.lower(Producto.nombre).like(q_like)
            | func.lower(Producto.descripcion).like(q_like)
        )
    if categoria_id is not None:
        consulta = consulta.where(Producto.categoria_id == categoria_id)
    if etiqueta_id is not None:
        consulta = consulta.join(
            ProductoEtiqueta, ProductoEtiqueta.producto_id == Producto.id
        ).where(ProductoEtiqueta.etiqueta_id == etiqueta_id)
    if solo_con_stock:
        consulta = consulta.where(Producto.stock > 0)

    # Total de coincidencias (sin skip ni limit).
    total = session.exec(select(func.count()).select_from(consulta.subquery())).one()

    consulta = (
        consulta.options(
            selectinload(Producto.categoria),
            selectinload(Producto.etiquetas),
        )
        .order_by(Producto.id)
        .offset(skip)
        .limit(limit)
    )
    items = list(session.exec(consulta).all())
    return total, items


def obtener_producto(session: Session, producto_id: int) -> Producto:
    """Un producto, aunque esté dado de baja, con categoría y etiquetas cargadas.
    404 si no existe."""
    consulta = (
        select(Producto)
        .where(Producto.id == producto_id)
        .options(selectinload(Producto.categoria), selectinload(Producto.etiquetas))
    )
    producto = session.exec(consulta).first()
    if producto is None:
        raise NoEncontradoError(f"RN-03: no existe un producto con id {producto_id}")
    return producto


def crear_producto(session: Session, datos: ProductoCreate) -> Producto:
    # RN-03: la categoría debe existir y estar activa.
    categoria = session.get(Categoria, datos.categoria_id)
    if categoria is None or not categoria.activo:
        raise NoEncontradoError(
            f"RN-03: la categoría {datos.categoria_id} no existe o no está activa")
    # RN-01: nombre único (sin distinguir mayúsculas).
    if _nombre_ya_existe(session, Producto, datos.nombre):
        raise ConflictoError(f"RN-01: ya existe el producto '{datos.nombre}'")
    producto = Producto.model_validate(datos)
    return _guardar(
        session, producto, f"RN-01: ya existe el producto '{datos.nombre}'"
    )


def patch_producto(session: Session, producto_id: int, datos: ProductoPatch) -> Producto:
    """PATCH: cambia solo los campos enviados."""
    producto = obtener_producto(session, producto_id)  # 404 si no existe
    cambios = datos.model_dump(exclude_unset=True)

    # Si se cambia la categoría, RN-03: debe existir y estar activa.
    if "categoria_id" in cambios:
        categoria = session.get(Categoria, cambios["categoria_id"])
        if categoria is None or not categoria.activo:
            raise NoEncontradoError(
                f"RN-03: la categoría {cambios['categoria_id']} no existe o no está activa")

    # RN-01: si se cambia el nombre, debe ser único (sin chocar contra el propio producto).
    if "nombre" in cambios and cambios["nombre"] != producto.nombre:
        if _nombre_ya_existe(session, Producto, cambios["nombre"], excluir_id=producto_id):
            raise ConflictoError(f"RN-01: ya existe el producto '{cambios['nombre']}'")

    producto.sqlmodel_update(cambios)
    return _guardar(session, producto, f"No se pudo actualizar el producto {producto_id}")


def desactivar_producto(session: Session, producto_id: int) -> Producto:
    """Baja LÓGICA: devuelve el producto con activo=False."""
    producto = obtener_producto(session, producto_id)  # 404 si no existe
    if not producto.activo:
        raise ConflictoError(f"RN-02: el producto {producto_id} ya está dado de baja")
    producto.activo = False
    return _guardar(session, producto, f"No se pudo dar de baja el producto {producto_id}")


def asociar_etiqueta(session: Session, producto_id: int, etiqueta_id: int) -> Producto:
    """Agrega una etiqueta a un producto. 409 si ya está asociada (RN-04)."""
    producto = obtener_producto(session, producto_id)  # 404
    etiqueta = session.get(Etiqueta, etiqueta_id)
    if etiqueta is None:
        raise NoEncontradoError(f"RN-03: no existe una etiqueta con id {etiqueta_id}")
    if etiqueta in producto.etiquetas:
        raise ConflictoError(
            f"RN-04: la etiqueta '{etiqueta.nombre}' ya está asociada al producto '{producto.nombre}'")
    producto.etiquetas.append(etiqueta)
    return _guardar(
        session, producto,
        f"RN-04: la etiqueta '{etiqueta.nombre}' ya está asociada al producto '{producto.nombre}'",
    )


def desasociar_etiqueta(session: Session, producto_id: int, etiqueta_id: int) -> None:
    """Quita la asociación. 404 si el producto no tiene esa etiqueta (RN-04)."""
    producto = obtener_producto(session, producto_id)  # 404
    etiqueta = session.get(Etiqueta, etiqueta_id)
    if etiqueta is None:
        raise NoEncontradoError(f"RN-03: no existe una etiqueta con id {etiqueta_id}")
    if etiqueta not in producto.etiquetas:
        raise NoEncontradoError(
            f"RN-04: la etiqueta '{etiqueta.nombre}' no está asociada al producto '{producto.nombre}'")
    producto.etiquetas.remove(etiqueta)
    session.add(producto)
    _confirmar(session, "No se pudo quitar la etiqueta del producto")


# ======================================================================
# FASE: PEDIDOS
# ======================================================================
def crear_pedido(session: Session, datos: PedidoCreate) -> Pedido:
    """Registra un pedido con sus líneas: TODO O NADA (RN-05).

    1. Valida TODAS las líneas antes de modificar nada.
    2. Calcula precio, subtotales y total (copia de nombre y precio).
    3. Descuenta el stock y crea el pedido y las líneas.
    4. Un solo commit (RN-06).
    """
    # --- Primera pasada: validar todo ---
    producto_ids = [d.producto_id for d in datos.detalles]
    if len(set(producto_ids)) != len(producto_ids):
        raise ConflictoError("RN-05: no se pueden repetir productos en un mismo pedido")

    lineas = []
    for detalle in datos.detalles:
        producto = session.get(Producto, detalle.producto_id)
        if producto is None:
            raise NoEncontradoError(
                f"RN-05: el producto {detalle.producto_id} no existe")
        if not producto.activo:
            raise NoEncontradoError(
                f"RN-05: el producto {detalle.producto_id} está dado de baja")
        if detalle.cantidad > producto.stock:
            raise ConflictoError(
                f"RN-05: stock insuficiente para '{producto.nombre}': "
                f"hay {producto.stock} y se pidieron {detalle.cantidad}")
        lineas.append((producto, detalle))

    # --- Segunda pasada: modificar y guardar ---
    subtotales = []
    for producto, detalle in lineas:
        subtotal = round(producto.precio * detalle.cantidad, 2)
        subtotales.append(subtotal)
        producto.stock -= detalle.cantidad
        session.add(producto)

    total = round(sum(subtotales), 2)

    pedido = Pedido(
        cliente_nombre=datos.cliente_nombre,
        direccion_entrega=datos.direccion_entrega,
        forma_pago=datos.forma_pago,
        notas=datos.notas,
        estado=EstadoPedido.PENDIENTE,
        total=total,
        fecha=datetime.now(timezone.utc),
    )
    session.add(pedido)
    session.flush()  # para que pedido tenga id

    for (producto, detalle), subtotal in zip(lineas, subtotales):
        linea = DetallePedido(
            pedido_id=pedido.id,
            producto_id=producto.id,
            nombre_producto=producto.nombre,
            precio_unitario=producto.precio,
            cantidad=detalle.cantidad,
            subtotal=subtotal,
        )
        session.add(linea)

    try:
        session.commit()
    except IntegrityError as exc:
        session.rollback()
        raise ConflictoError("RN-05: no se pudo registrar el pedido por un conflicto de datos") from exc
    except Exception:
        # Evita dejar cambios parciales en la sesión ante cualquier otro fallo.
        session.rollback()
        raise
    session.refresh(pedido)
    return pedido


def listar_pedidos(
    session: Session,
    estado: EstadoPedido | None = None,
    skip: int = 0,
    limit: int = 10,
) -> tuple[int, list[Pedido]]:
    """Pedidos paginados, del más nuevo al más viejo. Filtro opcional por estado."""
    consulta = select(Pedido)
    if estado is not None:
        consulta = consulta.where(Pedido.estado == estado)

    total = session.exec(select(func.count()).select_from(consulta.subquery())).one()

    consulta = (
        consulta.options(selectinload(Pedido.detalles))
        .order_by(Pedido.id.desc())
        .offset(skip)
        .limit(limit)
    )
    items = list(session.exec(consulta).all())
    return total, items


def resumen_pedidos(session: Session) -> dict:
    """Cantidad de pedidos por estado e ingresos de los entregados."""
    pendientes = session.exec(
        select(func.count(Pedido.id)).where(Pedido.estado == EstadoPedido.PENDIENTE)
    ).one()
    en_preparacion = session.exec(
        select(func.count(Pedido.id)).where(Pedido.estado == EstadoPedido.EN_PREPARACION)
    ).one()
    entregados = session.exec(
        select(func.count(Pedido.id)).where(Pedido.estado == EstadoPedido.ENTREGADO)
    ).one()
    cancelados = session.exec(
        select(func.count(Pedido.id)).where(Pedido.estado == EstadoPedido.CANCELADO)
    ).one()
    ingresos = session.exec(
        select(func.coalesce(func.sum(Pedido.total), 0)).where(
            Pedido.estado == EstadoPedido.ENTREGADO
        )
    ).one()
    return {
        "pendientes": pendientes,
        "en_preparacion": en_preparacion,
        "entregados": entregados,
        "cancelados": cancelados,
        "ingresos_entregados": ingresos,
    }


def obtener_pedido(session: Session, pedido_id: int) -> Pedido:
    """Un pedido con sus líneas ya cargadas. 404 si no existe."""
    consulta = (
        select(Pedido)
        .where(Pedido.id == pedido_id)
        .options(selectinload(Pedido.detalles))
    )
    pedido = session.exec(consulta).first()
    if pedido is None:
        raise NoEncontradoError(f"RN-03: no existe un pedido con id {pedido_id}")
    return pedido


def cambiar_estado_pedido(session: Session, pedido_id: int, nuevo_estado: EstadoPedido) -> Pedido:
    """Cambia el estado según las transiciones válidas (RN-06).

    Al cancelar (RN-07), el stock de cada línea vuelve al producto en la misma transacción.
    """
    pedido = obtener_pedido(session, pedido_id)  # 404
    estado_actual = pedido.estado
    if nuevo_estado not in TRANSICIONES_VALIDAS[estado_actual]:
        raise ConflictoError(
            f"RN-06: no se puede pasar de '{estado_actual.value}' a '{nuevo_estado.value}'")

    if nuevo_estado == EstadoPedido.CANCELADO:
        # RN-07: al cancelar, el stock de cada línea vuelve al producto.
        for detalle in pedido.detalles:
            producto = session.get(Producto, detalle.producto_id)
            if producto is not None:
                producto.stock += detalle.cantidad
                session.add(producto)

    pedido.estado = nuevo_estado
    return _guardar(session, pedido, f"No se pudo cambiar el estado del pedido {pedido_id}")


# ======================================================================
# Datos de ejemplo
# ======================================================================
def cargar_datos_de_ejemplo(session: Session) -> None:
    """Carga el catálogo SOLO si la tabla de productos está vacía.

    Al menos 4 categorías, 3 etiquetas y 12 productos, con etiquetas,
    con imágenes y con alguno sin stock.

    Todo en una sola transacción: se hace flush() para obtener los ids
    generados y un único commit() al final.
    """
    existe = session.exec(select(func.count()).select_from(Producto)).one()
    if existe > 0:
        return

    # --- Categorías ---
    categorias = []
    for nombre, desc in [
        ("Pizzas", "Masa casera a la piedra."),
        ("Hamburguesas", "Carne 100% vacuna, pan brioche."),
        ("Ensaladas", "Verduras frescas de estación."),
        ("Bebidas", "Refrescos, aguas y jugos naturales."),
    ]:
        categorias.append(Categoria(nombre=nombre, descripcion=desc, activo=True))
    session.add_all(categorias)
    session.flush()
    id_cat = {c.nombre: c.id for c in categorias}

    # --- Etiquetas (Etiqueta no tiene campo activo) ---
    etiquetas = []
    for nombre in ["Vegetariano", "Sin TACC", "Picante"]:
        etiquetas.append(Etiqueta(nombre=nombre))
    session.add_all(etiquetas)
    session.flush()
    id_etq = {e.nombre: e.id for e in etiquetas}

    # --- Productos ---
    productos = [
        ("Pizza muzzarella", "Masa casera, salsa de tomate y muzzarella.", 9200.0, 8,
         "img/pizza-muzzarella.jpg", "Pizzas", ["Vegetariano"]),
        ("Pizza napolitana", "Massa, tomate, muzzarella y rodajas de tomate.", 10500.0, 5,
         "img/pizza-napo.jpg", "Pizzas", ["Vegetariano"]),
        ("Hamburguesa clásica", "Carne, lechuga, tomate y huevo.", 8500.0, 12,
         "img/hamburguesa-clasica.jpg", "Hamburguesas", []),
        ("Hamburguesa completa", "Carne, queso, huevo, panceta y cebolla.", 11000.0, 6,
         "img/hamburguesa-completa.jpg", "Hamburguesas", ["Picante"]),
        ("Ensalada césar", "Lechuga, crutones, parmesano y aderezo césar.", 7200.0, 10,
         "img/ensalada-cesar.jpg", "Ensaladas", ["Vegetariano", "Sin TACC"]),
        ("Ensalada mixta", "Lechuga, tomate, cebolla y huevo.", 6500.0, 0,
         "img/ensalada-mixta.jpg", "Ensaladas", ["Vegetariano", "Sin TACC"]),
        ("Coca cola 500 ml", "Gaseosa clásica.", 1800.0, 20,
         "img/coca-cola.jpg", "Bebidas", []),
        ("Agua mineral sin gas", "Botella 620 cc.", 1200.0, 15,
         "img/agua-mineral.jpg", "Bebidas", ["Sin TACC"]),
        ("Jugo de naranja", "Jugo natural exprimido.", 2200.0, 9,
         "img/jugo-naranja.jpg", "Bebidas", ["Sin TACC"]),
        ("Pizza fugazzeta", "Massa, cebolla y muzzarella.", 11200.0, 4,
         "img/pizza-fugazza.jpg", "Pizzas", ["Vegetariano"]),
        ("Hamburguesa veggie", "Medallón de vegetales, lechuga y tomate.", 9500.0, 7,
         "img/hamburguesa-veggie.jpg", "Hamburguesas", ["Vegetariano"]),
        ("Ensalada griega", "Lechuga, tomate, cebolla, aceitunas y feta.", 8000.0, 3,
         "img/ensalada-griega.jpg", "Ensaladas", ["Vegetariano", "Sin TACC"]),
    ]

    productos_guardados = []
    for nombre, desc, precio, stock, imagen, cat_nombre, etq_nombres in productos:
        producto = Producto(
            nombre=nombre,
            descripcion=desc,
            precio=precio,
            stock=stock,
            imagen_url=imagen,
            categoria_id=id_cat[cat_nombre],
            activo=True,
        )
        session.add(producto)
        productos_guardados.append((producto, etq_nombres))
    session.flush()  # así ya tengo los id de los productos

    # --- Asociaciones producto <-> etiqueta ---
    for producto, etq_nombres in productos_guardados:
        for etq_nombre in etq_nombres:
            session.add(
                ProductoEtiqueta(
                    producto_id=producto.id,
                    etiqueta_id=id_etq[etq_nombre],
                )
            )

    session.commit()
