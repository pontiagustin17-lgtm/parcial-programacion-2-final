# Parcial 2 - Food Store API
Alumno: Ponti, Agustín

## Endpoints implementados y probados (TestClient, base SQLite en memoria)

Categorías:
- GET /categorias/              200  (activas, ordenadas por id)
- GET /categorias/{id}          200 / 404  (con productos anidados, selectinload)
- POST /categorias/             201 / 409  (RN-01 nombre único)
- PUT /categorias/{id}          200 / 404 / 409
- DELETE /categorias/{id}       200 / 404 / 409  (baja lógica, RN-02)

Etiquetas:
- GET /etiquetas/               200  (ordenadas por id)
- POST /etiquetas/              201 / 409  (RN-01 nombre único)
- DELETE /etiquetas/{id}        204 / 404 / 409  (borrado físico, RN-02)

Productos:
- GET /productos/               200  (paginado, filtros q / categoria_id / etiqueta_id / solo_con_stock / skip / limit)
- GET /productos/{id}           200 / 404  (aunque esté de baja, con categoría y etiquetas)
- POST /productos/              201 / 404 / 409  (RN-03 categoría válida, RN-01)
- PATCH /productos/{id}         200 / 404 / 409  (campos opcionales, RN-01 / RN-03)
- DELETE /productos/{id}        200 / 404 / 409  (baja lógica)
- POST /productos/{id}/etiquetas/{etiqueta_id}  201 / 404 / 409  (RN-04)
- DELETE /productos/{id}/etiquetas/{etiqueta_id} 204 / 404  (RN-04)

Pedidos:
- POST /pedidos/                201 / 404 / 409 / 422  (RN-05, un solo commit)
- GET /pedidos/                 200  (paginado, más nuevo primero, filtro estado)
- GET /pedidos/resumen          200  (pendientes, en_preparacion, entregados, cancelados, ingresos_entregados)
- GET /pedidos/{id}             200 / 404  (con líneas)
- PATCH /pedidos/{id}/estado    200 / 404 / 409  (RN-06 transiciones, RN-07 devolución de stock)

## Reglas de negocio verificadas
- RN-01: Nombres únicos sin distinguir mayúsculas (categoría, etiqueta, producto) -> 409
- RN-02: Bajas protegidas (categoría con productos activos, etiqueta en uso, ya de baja) -> 409
- RN-03: Categoría existente y activa para crear/mover producto -> 404
- RN-04: Etiqueta no duplicada en producto / quitar asociación inexistente -> 409 / 404
- RN-05: Pedido con al menos una línea / sin productos repetidos / productos activos y con stock -> 422 / 404 / 409
- RN-06: Transiciones de estado válidas (diccionario) -> 409
- RN-07: Cancelación devuelve el stock de cada línea en la misma transacción

## Modelo de datos
6 tablas: categoria, producto, etiqueta, productoetiqueta (N a N, clave primaria compuesta), pedido, detallepedido.
2 enums: FormaPago (EFECTIVO, TRANSFERENCIA), EstadoPedido (PENDIENTE, EN_PREPARACION, ENTREGADO, CANCELADO).
Relaciones con Relationship, back_populates y link_model. DetallePedido guarda copia de nombre y precio.

## Datos de ejemplo (cargar_datos_de_ejemplo)
4 categorías, 3 etiquetas, 12 productos, con etiquetas, con imágenes en `img/` y uno sin stock.
Carga en una sola transacción (`flush()` para obtener los ids y un único `commit()` al final)
y solo si la tabla de productos está vacía.

## Arquitectura
Capas separadas: routers (solo HTTP, traducen excepciones, nunca hacen commit),
service (reglas de negocio, transacciones, única capa con add/commit/rollback, sin FastAPI),
schemas (modelos de entrada/salida separados de las tablas), database (engine, get_session, crear_tablas).

## Ejecución
    pip install -r requirements.txt
    uvicorn main:app --reload
Documentación: http://127.0.0.1:8000/docs

## Entrega
Un único archivo .zip con la estructura indicada (incluida la carpeta `img/`),
sin venv, `__pycache__` ni archivos .db.
