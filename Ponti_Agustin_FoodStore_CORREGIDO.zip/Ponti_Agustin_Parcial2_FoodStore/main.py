# -*- coding: utf-8 -*-
"""
main.py -- Punto de entrada: crea la app, prepara la base al arrancar e
incluye los routers.

Levantar el servidor real (desde esta carpeta):
    uvicorn main:app --reload
y abrir http://127.0.0.1:8000/docs

Por defecto usa SQLite (archivo foodstore.db). Con PostgreSQL, definir antes la URL:
    PowerShell:  $env:DATABASE_URL = "postgresql+psycopg://usuario:clave@localhost:5432/foodstore"
    uvicorn main:app --reload
"""

from contextlib import asynccontextmanager

from fastapi import FastAPI

import database
import service
from router_categorias import router as router_categorias
from router_etiquetas import router as router_etiquetas
from router_productos import router as router_productos
from router_pedidos import router as router_pedidos


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Se ejecuta UNA vez al arrancar: crea las tablas y, si están vacías, las siembra.
    database.crear_tablas()
    from sqlmodel import Session
    with Session(database.engine) as session:
        service.cargar_datos_de_ejemplo(session)
    yield


app = FastAPI(
    title="Food Store API",
    description=("API REST de un negocio de comidas: categorías, productos con etiquetas, "
                 "pedidos con múltiples líneas, estados del pedido y stock."),
    version="1.0.0",
    lifespan=lifespan,
)

app.include_router(router_categorias)
app.include_router(router_etiquetas)
app.include_router(router_productos)
app.include_router(router_pedidos)


@app.get("/", tags=["Estado"])
def raiz():
    return {"mensaje": "Food Store API funcionando", "documentación": "/docs"}
