# -*- coding: utf-8 -*-
"""
router_etiquetas.py -- Los endpoints del recurso /etiquetas.

Mismo esqueleto: FastAPI valida -> se delega en el service ->
las excepciones de dominio se traducen a HTTP. Sin reglas de negocio y SIN commit.
"""

from typing import Annotated

from fastapi import APIRouter, HTTPException, Path, status

import service
from database import SessionDep
from schemas import EtiquetaCreate, EtiquetaPublic
from service import ConflictoError, NoEncontradoError

router = APIRouter(prefix="/etiquetas", tags=["Etiquetas"])

EtiquetaId = Annotated[int, Path(gt=0, description="ID de la etiqueta")]


@router.get("/", response_model=list[EtiquetaPublic])
def listar_etiquetas(session: SessionDep):
    """Lista las etiquetas, ordenadas por id."""
    return service.listar_etiquetas(session)


@router.post("/", response_model=EtiquetaPublic, status_code=status.HTTP_201_CREATED)
def crear_etiqueta(datos: EtiquetaCreate, session: SessionDep):
    try:
        return service.crear_etiqueta(session, datos)
    except ConflictoError as error:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(error))


@router.delete("/{etiqueta_id}", status_code=status.HTTP_204_NO_CONTENT)
def eliminar_etiqueta(etiqueta_id: EtiquetaId, session: SessionDep):
    """Borrado FÍSICO, sin cuerpo en la respuesta. 204."""
    try:
        service.eliminar_etiqueta(session, etiqueta_id)
    except NoEncontradoError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(error))
    except ConflictoError as error:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(error))
