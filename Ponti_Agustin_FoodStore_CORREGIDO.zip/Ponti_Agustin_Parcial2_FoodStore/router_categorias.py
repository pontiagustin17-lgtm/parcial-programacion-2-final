# -*- coding: utf-8 -*-
"""
router_categorias.py -- Los endpoints del recurso /categorías.

FastAPI valida -> se delega en el service ->
las excepciones de dominio se traducen a HTTP (NoEncontradoError -> 404,
ConflictoError -> 409). Sin reglas de negocio y SIN commit.
"""

from typing import Annotated

from fastapi import APIRouter, HTTPException, Path, status

import service
from database import SessionDep
from schemas import (
    CategoriaConProductos,
    CategoriaCreate,
    CategoriaPublic,
)
from service import ConflictoError, NoEncontradoError

router = APIRouter(prefix="/categorias", tags=["Categorías"])

CategoriaId = Annotated[int, Path(gt=0, description="ID de la categoría")]


@router.get("/", response_model=list[CategoriaPublic])
def listar_categorias(session: SessionDep):
    """Lista las categorías activas, ordenadas por id."""
    return service.listar_categorias(session)


@router.get("/{categoria_id}", response_model=CategoriaConProductos)
def obtener_categoria(categoria_id: CategoriaId, session: SessionDep):
    """Devuelve una categoría con la lista de productos."""
    try:
        return service.obtener_categoria(session, categoria_id)
    except NoEncontradoError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(error))


@router.post("/", response_model=CategoriaPublic, status_code=status.HTTP_201_CREATED)
def crear_categoria(datos: CategoriaCreate, session: SessionDep):
    try:
        return service.crear_categoria(session, datos)
    except ConflictoError as error:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(error))


@router.put("/{categoria_id}", response_model=CategoriaPublic)
def reemplazar_categoria(categoria_id: CategoriaId, datos: CategoriaCreate, session: SessionDep):
    try:
        return service.reemplazar_categoria(session, categoria_id, datos)
    except NoEncontradoError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(error))
    except ConflictoError as error:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(error))


@router.delete("/{categoria_id}", response_model=CategoriaPublic)
def desactivar_categoria(categoria_id: CategoriaId, session: SessionDep):
    """Baja lógica: devuelve la categoría con activo en false."""
    try:
        return service.desactivar_categoria(session, categoria_id)
    except NoEncontradoError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(error))
    except ConflictoError as error:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(error))
