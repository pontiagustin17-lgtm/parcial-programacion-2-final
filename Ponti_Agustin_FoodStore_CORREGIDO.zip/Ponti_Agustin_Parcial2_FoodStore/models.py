# -*- coding: utf-8 -*-
"""
models.py -- Las TABLAS de la base de datos (table=True) y los ENUM.

Un modelo con table=True es una tabla: cada atributo es una columna y cada
instancia es una fila. Es lo que guarda SQLModel, NO lo que sale por HTTP:
hacia afuera se devuelven los schemas de schemas.py (response_model).

Relaciones (ver Figura 1 de la consigna):
    Categoria 1 ---- N Producto        (Producto.categoria_id, Categoria.productos, Producto.categoria)
    Producto N ---- N Etiqueta         (tabla intermedia ProductoEtiqueta, link_model)
    Pedido 1 ---- N DetallePedido      (DetallePedido.pedido_id, Pedido.detalles, DetallePedido.pedido)
    Producto 1 ---- N DetallePedido    (DetallePedido.producto_id, Producto.detalles, DetallePedido.producto)

FormaPago y EstadoPedido son Enum. DetallePedido guarda una copia del nombre
y del precio del producto: si mañana el producto cambia de precio, los pedidos
ya hechos no cambian.
"""

from datetime import datetime
from enum import Enum
from typing import Optional

from sqlmodel import Field, Relationship, SQLModel


# ======================================================================
# Enums
# ======================================================================
class FormaPago(str, Enum):
    EFECTIVO = "EFECTIVO"
    TRANSFERENCIA = "TRANSFERENCIA"


class EstadoPedido(str, Enum):
    PENDIENTE = "PENDIENTE"
    EN_PREPARACION = "EN_PREPARACION"
    ENTREGADO = "ENTREGADO"
    CANCELADO = "CANCELADO"


# ======================================================================
# Tabla intermedia N a N: Producto <-> Etiqueta (clave primaria compuesta)
# ======================================================================
class ProductoEtiqueta(SQLModel, table=True):
    producto_id: int = Field(foreign_key="producto.id", primary_key=True)
    etiqueta_id: int = Field(foreign_key="etiqueta.id", primary_key=True)


# ======================================================================
# Categoria (lado "1" de la 1 a N con Producto)
# ======================================================================
class CategoriaBase(SQLModel):
    nombre: str = Field(min_length=2, max_length=50, index=True, unique=True)
    descripcion: str = Field(max_length=200)
    activo: bool = Field(default=True)


class Categoria(CategoriaBase, table=True):
    id: int | None = Field(default=None, primary_key=True)
    # Lado "uno" de la relación 1 a N con Producto.
    productos: list["Producto"] = Relationship(back_populates="categoria")


# ======================================================================
# Etiqueta (lado "N" de la N a N con Producto)
# ======================================================================
class EtiquetaBase(SQLModel):
    nombre: str = Field(min_length=2, max_length=30, index=True, unique=True)


class Etiqueta(EtiquetaBase, table=True):
    id: int | None = Field(default=None, primary_key=True)
    # Lado "N" de la relación N a N con Producto, a través de ProductoEtiqueta.
    productos: list["Producto"] = Relationship(
        back_populates="etiquetas", link_model=ProductoEtiqueta
    )


# ======================================================================
# Producto (lado "N" de la 1 a N con Categoria; lado "N" de la N a N con Etiqueta)
# ======================================================================
class ProductoBase(SQLModel):
    """Los campos que comparten la entrada, la salida y la tabla."""
    nombre: str = Field(min_length=3, max_length=60, index=True, unique=True)
    descripcion: str = Field(max_length=200)
    precio: float = Field(gt=0)
    stock: int = Field(default=0, ge=0)
    imagen_url: str | None = Field(default=None, max_length=255)
    categoria_id: int = Field(foreign_key="categoria.id", index=True)
    activo: bool = Field(default=True)


class Producto(ProductoBase, table=True):
    """La TABLA: agrega id y las relaciones."""
    id: int | None = Field(default=None, primary_key=True)

    # Lado "N" de la relación 1 a N con Categoria.
    categoria: Optional[Categoria] = Relationship(back_populates="productos")

    # Lado "N" de la relación N a N con Etiqueta, a través de ProductoEtiqueta.
    etiquetas: list[Etiqueta] = Relationship(
        back_populates="productos", link_model=ProductoEtiqueta
    )

    # Lado "1" de la relación 1 a N con DetallePedido.
    detalles: list["DetallePedido"] = Relationship(back_populates="producto")


# ======================================================================
# Pedido (lado "1" de la 1 a N con DetallePedido)
# ======================================================================
class PedidoBase(SQLModel):
    cliente_nombre: str = Field(min_length=3, max_length=80)
    direccion_entrega: str = Field(min_length=5, max_length=200)
    forma_pago: FormaPago
    notas: str | None = Field(default=None, max_length=200)


class Pedido(PedidoBase, table=True):
    """La TABLA del pedido: agrega id, estado, total, fecha y las líneas."""
    id: int | None = Field(default=None, primary_key=True)
    estado: EstadoPedido = Field(default=EstadoPedido.PENDIENTE)
    total: float = Field(default=0.0)
    fecha: datetime
    # Lado "uno" de la relación 1 a N con DetallePedido.
    detalles: list["DetallePedido"] = Relationship(back_populates="pedido")


# ======================================================================
# DetallePedido (lado "N" de la 1 a N con Pedido y con Producto)
# ======================================================================
class DetallePedidoBase(SQLModel):
    producto_id: int = Field(foreign_key="producto.id", index=True)
    nombre_producto: str = Field(max_length=60)   # copia del nombre al momento de la venta
    precio_unitario: float                        # copia del precio al momento de la venta
    cantidad: int = Field(ge=1)
    subtotal: float


class DetallePedido(DetallePedidoBase, table=True):
    id: int | None = Field(default=None, primary_key=True)
    pedido_id: int = Field(foreign_key="pedido.id", index=True)

    # Relaciones de vuelta hacia Pedido y Producto.
    pedido: Optional[Pedido] = Relationship(back_populates="detalles")
    producto: Optional[Producto] = Relationship(back_populates="detalles")
